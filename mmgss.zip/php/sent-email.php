<?php

declare(strict_types=1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: text/plain; charset=UTF-8');

// Keep Composer dependencies in the project root: /vendor/autoload.php
$autoload = __DIR__ . '/../vendor/autoload.php';
if (!is_file($autoload)) {
    http_response_code(500);
    error_log('MMGSS contact form: Composer autoload file was not found.');
    exit('The contact form is temporarily unavailable. Please contact the company directly.');
}
require $autoload;

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Please submit the contact form.');
}

$name     = trim((string) ($_POST['name'] ?? ''));
$company  = trim((string) ($_POST['company'] ?? ''));
$email    = trim((string) ($_POST['email'] ?? ''));
$phone    = trim((string) ($_POST['phone'] ?? ''));
$interest = trim((string) ($_POST['interest'] ?? ''));
$message  = trim((string) ($_POST['message'] ?? ''));

if ($name === '' || $company === '' || $email === '' || $phone === '' || $interest === '' || $message === '') {
    http_response_code(400);
    exit('Please fill in all required fields.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    exit('Please enter a valid email address.');
}

// Configure these environment variables in your hosting control panel.

$smtpHost     = 'mail.myanmargss.com';
$smtpUsername = 'contact@myanmargss.com';
$smtpPassword = getenv('UJgPF&x]!gup!)jT') ?: '';
$recipient    = 'seteam@nicemyanmartravel.com';
$smtpPort     = 465;
$smtpSecure   = 'smtps';


if ($smtpHost === '' || $smtpUsername === '' || $smtpPassword === '' || $recipient === '') {
    http_response_code(500);
    error_log('MMGSS contact form: SMTP environment configuration is incomplete.');
    exit('The contact form is not configured yet. Please contact the company directly.');
}

if (!filter_var($smtpUsername, FILTER_VALIDATE_EMAIL) || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
    http_response_code(500);
    error_log('MMGSS contact form: SMTP username or recipient is not a valid email address.');
    exit('The contact form is temporarily unavailable. Please contact the company directly.');
}

try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = $smtpHost;
    $mail->SMTPAuth   = true;
    $mail->Username   = $smtpUsername;
    $mail->Password   = $smtpPassword;
    $mail->Port       = $smtpPort;
    $mail->CharSet    = 'UTF-8';
    $mail->Timeout    = 20;

    if ($smtpSecure === 'smtps' || $smtpSecure === 'ssl') {
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    } elseif ($smtpSecure === 'starttls' || $smtpSecure === 'tls') {
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    } else {
        throw new RuntimeException('Unsupported SMTP encryption setting.');
    }

    // The From address should match the authenticated mailbox.
    $mail->setFrom($smtpUsername, 'Myanmar GSS Website');
    $mail->addAddress($recipient);
    $mail->addReplyTo($email, $name);
    $mail->isHTML(true);
    $mail->Subject = 'New Contact Form Message from ' . $name;

    $safeName     = htmlspecialchars($name, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeCompany  = htmlspecialchars($company, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeEmail    = htmlspecialchars($email, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safePhone    = htmlspecialchars($phone, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeInterest = htmlspecialchars($interest, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeMessage  = nl2br(htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));

    $mail->Body = "
        <div style='font-family:Arial,sans-serif;padding:20px;color:#333'>
            <h2 style='color:#b50909'>New Contact Form Submission</h2>
            <hr style='border:0;border-top:1px solid #eee;margin:15px 0'>
            <p><strong>Name:</strong> {$safeName}</p>
            <p><strong>Company:</strong> {$safeCompany}</p>
            <p><strong>Email:</strong> {$safeEmail}</p>
            <p><strong>Phone:</strong> {$safePhone}</p>
            <p><strong>Inquiry topic:</strong> {$safeInterest}</p>
            <p><strong>Message:</strong></p>
            <div style='background:#f9f9f9;padding:15px;border-left:4px solid #b50909;margin-top:10px'>
                {$safeMessage}
            </div>
        </div>
    ";
    $mail->AltBody = "New Contact Form Submission\n\nName: {$name}\nCompany: {$company}\nEmail: {$email}\nPhone: {$phone}\nInquiry topic: {$interest}\n\nMessage:\n{$message}";

    $mail->send();
    echo 'Message sent successfully!';
} catch (Throwable $e) {
    // Keep SMTP details out of the public response; inspect the server error log.
    error_log('MMGSS contact form mail error: ' . $e->getMessage());
    http_response_code(500);
    echo 'Message could not be sent. Please try again later.';
}
